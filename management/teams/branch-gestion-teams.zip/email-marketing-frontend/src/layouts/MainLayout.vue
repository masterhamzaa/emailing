<template>
  <q-layout view="lHh Lpr lFf">
    <q-header elevated>
      <q-toolbar>
        <q-btn flat dense round icon="menu" aria-label="Menu" @click="toggleLeftDrawer" />

        <q-toolbar-title> {{ user.name }} </q-toolbar-title>

        <div>

          <q-btn @click="logout" :loading="loading" icon="logout" label="Logout" />


        </div>
      </q-toolbar>
    </q-header>

    <q-drawer v-model="leftDrawerOpen" show-if-above bordered class="bg-primary text-white">
      <q-list>
        <q-item to="/admin" active-class="q-item-no-link-highlighting">
          <q-item-section avatar>
            <q-icon name="dashboard" />
          </q-item-section>
          <q-item-section>
            <q-item-label>Dashboard</q-item-label>
          </q-item-section>
        </q-item>
        <q-item v-if="1" to="/admin/users" active-class="q-item-no-link-highlighting">
          <q-item-section avatar>
            <q-icon name="person" />
          </q-item-section>

          <q-item-section>
            <q-item-label>Gestion Users</q-item-label>
          </q-item-section>
        </q-item>

        <q-item to="/admin/teams" active-class="bg-blue-grey-5">
          <q-item-section avatar>
            <q-icon name="groups" />
          </q-item-section>
          <q-item-section>
            <q-item-label>Management Teams</q-item-label>
          </q-item-section>
        </q-item>

        <q-item v-if="user.id===1 || user.id===55" to="/admin/permissions" active-class="q-item-no-link-highlighting">
          <q-item-section avatar>
            <q-icon name="security" />
          </q-item-section>
          <q-item-section>
            <q-item-label>Permissions</q-item-label>
          </q-item-section>
        </q-item>

        <q-item v-if="user.id===1" to="/admin/roles" active-class="q-item-no-link-highlighting">
          <q-item-section avatar>
            <q-icon name="security" />
          </q-item-section>
          <q-item-section>
            <q-item-label>Roles</q-item-label>
          </q-item-section>
        </q-item>
        <q-item-label header> App Features </q-item-label>

        <EssentialLink v-for="link in essentialLinks" :key="link.title" v-bind="link" />

      </q-list>

    </q-drawer>

    <q-page-container>
      <router-view />
    </q-page-container>
  </q-layout>
</template>

<script>
import { api } from "src/boot/axios";
import { useRouter } from "vue-router";
import { defineComponent, ref } from "vue";
import EssentialLink from "components/EssentialLink.vue";
import { useAuthStore } from "src/stores/auth-store";

const linksList = [
  {
    title: "Docs",
    caption: "quasar.dev",
    icon: "school",
    link: "https://quasar.dev",
  },
  {
    title: "Github",
    caption: "github.com/quasarframework",
    icon: "code",
    link: "https://github.com/quasarframework",
  },
  {
    title: "Github",
    caption: "github.com/quasarframework",
    icon: "code",
    link: "https://github.com/quasarframework",
  },

];

const authStore = useAuthStore();

export default defineComponent({
  name: "MainLayout",
  beforeRouteEnter(to, from, next) {
    api
      .get("v1/user")
      .then((response) => {
        authStore.user = response.data.data;
        next();
      })
      .catch((error) => {
        if (error.response.status === 401) {
          
          next({ name: "login" });
        }
      });
  },
  setup() {
    const leftDrawerOpen = ref(false);
    const user = authStore.user;
    const loading = ref(false);
    const router = useRouter();
    const logout = async () => {
      loading.value = true;
      try {
        await api.post("/v1/logout");
        router.push({ name: "login" });
      } catch (error) {
        console.log(error);
      } finally {
        loading.value = false;
      }
    };
    return {
      logout,
      loading,
      user,
      essentialLinks: linksList,
      leftDrawerOpen,
      toggleLeftDrawer() {
        leftDrawerOpen.value = !leftDrawerOpen.value;
      },
    };
  },
});
</script>
