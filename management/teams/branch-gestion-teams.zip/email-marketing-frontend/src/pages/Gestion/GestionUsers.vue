<template>
  <div class="q-pa-md">

    <!-- ADD USER -->
    <q-dialog v-model="adduser">
      <q-card class="my-card">
        <q-card-section>
          <q-form class="q-gutter-md">
            <!--  <q-input label="id" v-model="iduser" type="number" lazy-rules /> -->
            <q-input autofocus label="Name" v-model="nameuser" name="name" type="text" lazy-rules />
            <q-input label="Email" v-model="email" type="email" name="email" lazy-rules />
            <q-input label="Password" v-model="password" type="password" name="password" lazy-rules required />
            <div class="q-pa-md">
              <div class="q-gutter-md row items-start">
                <q-select filled v-model="roleadd" :options="optionRole" name="role" label="Role"
                  style="width: 300px;margin-left: -2px;" />
                <!--  <q-select filled v-model="permissionsadd" multiple :options="optionsPermissions" label="Permissions"
                  style="width: 250px" /> -->
              </div>
            </div>

          </q-form>
        </q-card-section>
        <q-separator />
        <q-card-actions align="right">
          <q-btn flat color="blue" round icon="add"  @click="()=>{addUser();adduser=false}" />
          <q-btn v-close-popup flat color="primary" label="close" />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!-- EDIT USER -->
    <q-dialog v-model="edituser">
      <q-card class="my-card">
        <q-card-section>
          <q-form class="q-gutter-md">
            <!-- <q-input label="id" v-model="id" lazy-rules /> -->
            <q-input label="Name" type="text" v-model="nameuser"  name="name"    autofocus lazy-rules style="width: 300px" />
            <q-input label="Email" v-model="email" type="email" name="email"  lazy-rules style="width: 300px" />
            <q-input label="Password" v-model="password" type="password" name="password" lazy-rules required style="width: 300px"/>

          </q-form>
        </q-card-section>
        <q-separator />
        <q-card-actions align="right">
          <q-btn flat color="green" round icon="edit"  @click="()=>{editUser();edituser=false}" />
          <q-btn v-close-popup flat color="primary" label="close" />
        </q-card-actions>
      </q-card>
    </q-dialog>

    <!-- DISPLAY DATA -->
    <q-table flat bordered :rows="users" :columns="columns" row-key="id" :filter="filter" :loading="loading"
      selection="multiple" v-model:selected="selected">
      <template v-slot:top>
        <q-btn color="primary"  :disable="selected.length > 0" label="Add User" @click="adduser = true" />
        <q-btn class="q-ml-sm" color="red" :disable="selected.length === 0" label="Remove user" @click="removeUser" />
        <q-btn class="q-ml-sm" label="Edit User" color="blue" :disable="selected.length === 0 || selected.length > 1" @click="()=>{
          nameuser=selected[0].name
          email=selected[0].email
          edituser = true
        }" />
        <q-space />
        <q-input borderless dense debounce="300" color="primary" v-model="filter">
          <template v-slot:append>
            <q-icon name="search" />
          </template>
        </q-input>
      </template>
      <template v-slot:no-data="{ icon, message, filter }">
        <div class="full-width row flex-center text-accent q-gutter-sm">
          <q-icon size="2em" name="sentiment_dissatisfied" />
          <span>
            Well this is sad... {{ message }}
          </span>
          <q-icon size="2em" :name="filter ? 'filter_b_and_w' : icon" />
        </div>
      </template>
    </q-table>
    <div class="q-mt-md">
      <!-- Selected: {{ JSON.stringify(selected) }} -->
    </div>
  </div>
</template>

<script>
import { defineComponent, ref } from 'vue'
import { useStrorage } from "src/stores/storage";
import { api } from "src/boot/axios";
const Storage = useStrorage();
const users = ref([])
const columns = [
  { name: 'id', align: 'left', label: 'id', field: 'id', sortable: true },
  { name: 'Name', align: 'left', label: 'Name', field: 'name', sortable: true },
  { name: 'Email', align: 'left', label: 'Email', field: 'email' },
]

const getdata = async () => {
  await api
    .get("v1/users")
    .then((response) => {
      Storage.users = response.data.data;
      users.value = Storage.users
      console.log(users)
    })
    .catch((error) => {
      console.log(error)
    });
}
export default defineComponent({
  // eslint-disable-next-line vue/multi-word-component-names
  name: "users",
  created() { getdata() },
  setup() {

    let valid = ref(false);
    const loading = ref(false), filter = ref(''), rowCount = ref(10), rows = ref([]), selected = ref([])
    // add user
    const iduser = ref(null), nameuser = ref(""), email = ref(""), password = ref(""), roleadd = ref(""), permissionsadd = ref([])
    return {
      valid,users,optionRole: ['admin', 'standard'],
      //optionsPermissions: ['add_user', 'delete_user', 'edit_user', 'view_all_servers'],
      //edit test
      edituser: ref(false),
      //add user
      adduser: ref(false), iduser, nameuser, email, password, roleadd, //permissionsadd,
      //table
      columns, rows, loading, filter, rowCount, selected,
      // Operations Logic
      addUser() {
        if (nameuser.value !== "", email.value !== "" && password.value !== "" && roleadd.value !== null) {
          valid.value = true
        }
        if (valid.value) {
          loading.value = true
          setTimeout(() => {
            try {
              api.post("v1/admin/add_user", {
                name: nameuser.value,
                email: email.value,
                password: password.value,
                role: roleadd.value
              }).then(res => console.log(res)).catch(e => console.log(e))
              getdata()
              loading.value = false
              nameuser.value = ""; email.value = ""; password.value = ""; roleadd.value = null; selected.value = []
            } catch (e)
            {
              console.log(e)
            }
          }, 10)
        } else alert("fill all the fields ...")
      },
      removeUser() {
        loading.value = true
        setTimeout(() => {
          try {
            selected.value.forEach(row => {
              const index = rows.value.indexOf(row);
              console.log(index)
              console.log(rows.value)
              if (index !== -1) {
                rows.value.splice(index, 1);
              }
              api.delete("v1/users/" + row.id, row).then(res => console.log(res)).catch(e => console.log(e))
            });
            selected.value = []
            getdata()
            loading.value = false

          } catch (e) {
            console.log(e)
          }
        }, 1000)
      },
      editUser() {
        if (nameuser.value !== "", email.value !== "" && password.value !== "") {
          valid.value = true
        }
        if (valid.value) {
        setTimeout(() => {
          loading.value = true
          try {
              api.post("v1/admin/edit_user", {
                iduser:selected.value[0].id,
                name: nameuser.value,
                email: email.value,
                password: password.value,
              }).then(res => console.log(res)).catch(e => console.log(e))
              getdata()
              loading.value = false
              nameuser.value = ""; email.value = ""; password.value = "";selected.value = []
            } catch (e) {
              console.log(e)
            }
        }, 10)
      }else alert("check your fields!")},

    }
  }
})
</script>

