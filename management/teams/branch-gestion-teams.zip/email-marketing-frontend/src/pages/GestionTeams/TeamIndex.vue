<template>
    <div class="q-pa-md">
        <!-- Table Teams-->
      <q-table
        flat bordered
        title="Teams"
        :rows="team"
        :columns="columns"
        row-key="name"
        :rows-number="44"
        :pagination="pagination"
        :filter="false&&filter"
        :loading="loading"
        selection="multiple"
        @update:pagination="queryTeamSorting"
        v-model:selected="selected"
      >

      <!-- Exception If Data Not Found -->
      <template v-slot:no-data="{ icon, message, filter }">
        <div class="full-width row flex-center text-accent q-gutter-sm">
          <q-icon size="2em" name="sentiment_dissatisfied" />
          <span>
            Well this is sad... {{ message }}
          </span>
          <q-icon size="2em" :name="filter ? 'filter_b_and_w' : icon" />
        </div>
      </template>

      <!-- Button Update Team -->

          <template v-slot:body-cell-update="props">
            <q-td :props="props">
              <q-btn icon="mode_edit" @click="()=>{dialogUpdate = true,afterupdateTeam(props.row.idTeam,props.row.name,props.row.membres,props.row.active,props.row.teamLeader)}" color="green"></q-btn>
            </q-td>
          </template>

          <!-- Toggle Active -->
          <template v-slot:body-cell-active="props">
            <q-td :props="props">
                <q-toggle
                    @click="()=>ChangeTeamActiveStatus(props.row.idTeam,props.row.active)"
                    v-model="props.row.active"
                    checked-icon="check"
                    color="blue"
                    unchecked-icon="clear"
                />
            </q-td>
          </template>

          <!-- Drop Down Membres -->
          <template v-slot:body-cell-membres="props">
            <q-td :props="props">
            <div class="q-pa-md">
              <q-btn-dropdown color="black" label="Memebres" dropdown-icon="change_history">
                <q-list>
                  <q-item clickable v-close-popup v-for="(item,index) in props.row.membres" :key="index">
                    <q-item-section>
                      <q-item-label>{{ item.name }}</q-item-label>
                    </q-item-section>
                  </q-item>
                </q-list>
              </q-btn-dropdown>
            </div>
           </q-td>
          </template>
          
        <template v-slot:top-right>
          <!-- Button Add Team-->
            <q-btn color="secondary" :disable="false"  @click="()=>{dialog = true,afterCreateTeam()}" label="Add Team" />

            <!-- Dialog Add or Update Team-->
            <div class="q-pa-md q-gutter-sm">
                <q-dialog v-model="dialog" >
                <q-card style="width: 700px; max-width: 80vw;background-color: #293041; color:#fff;">
                  <q-card-section>
                    <div class="text-h6">{{ updateIcon?'Update Team':'Add Team' }}</div>
                  </q-card-section>

                  <q-card-section class="q-pt-none">
                    Management Teams
                  </q-card-section>

                  <q-card-section class="bg-white text-teal">
                    <!-- Dialog Add or Update Team : Input Name-->
                    <q-input v-model="nameTeam" @update:model-value="listenUpdateValue=true" label="Name" style="width:80% ;margin:0 auto;" />

                    <div class="q-pa-md" style="width:85% ;margin:0 auto;">
                      <div class="q-gutter-md">
                        <q-badge color="indigo" multi-line>
                          Team Leader: "{{ selectTeamLeader.name }}"
                        </q-badge>

                    <!-- Dialog Add or Update Team : Select TeamLeader-->
                        <q-select
                          filled
                          v-model="selectTeamLeader"
                          :options="users"
                          map-options
                          stack-label
                          emit-value
                          @update:model-value="listenUpdateValue=true"
                          :display-value="`TeamLeader: ${selectTeamLeader.name ? selectTeamLeader.name : ''}`"
                        >
                        <!-- Dialog Add or Update Team : Select TeamLeader : Icon Close In Select-->
                          <template v-slot:append>
                            <q-icon
                              class="cursor-pointer"
                              name="close"
                              @click.stop.prevent="selectTeamLeader= ''"
                            />
                          </template>
                          <!-- Dialog Add or Update Team : Select TeamLeader : Parts Select-->
                          <template v-slot:option="{ itemProps, opt, selected, toggleOption }">
                            <q-item v-bind="itemProps">
                              <q-item-section>
                                {{ opt.name }}
                              </q-item-section>
                              <q-item-section side :model-value="selected" @update:model-value="toggleOption(opt)">
                              </q-item-section>
                            </q-item>
                          </template>
                        </q-select>
                      </div>
                    </div>

                    <!-- Dialog Add or Update Team : Select Membres-->
                    <div class="q-pa-md">
                      <q-select
                        filled
                        label="Membres"
                        v-model="selectMembres"
                        option-label="name"
                        use-chips
                        multiple
                        map-options
                        emit-value
                        input-debounce="0"
                        @filter="filterFn"
                        :options="teamMembres"
                        @new-value="createValue"
                        @update:model-value="listenUpdateValue=true"
                        style="width:85% ;margin:0 auto;"
                      >
                      <!-- Dialog Add or Update Team : Select Membres : Parts Select-->
                      <template v-slot:option="{ itemProps, opt, selected, toggleOption }">
                        <q-item v-bind="itemProps">
                          <q-item-section>
                            {{ opt.name }}
                          </q-item-section>
                          <q-item-section side :model-value="selected" @update:model-value="toggleOption(opt)">
                          </q-item-section>
                        </q-item>
                      </template>
                    </q-select>
                    </div>

                    <!-- Dialog Add or Update Team : Icon Toggle For Status Active|| Inactive-->
                    <div style="width:80% ;margin:0 auto;">
                      <span class="label text-black">Status </span>
                        <q-toggle
                          :label="teamToggleActive?'Active':'Inactive'"
                          @click="clickme"
                          @update:model-value="listenUpdateValue=true"
                          v-model="teamToggleActive"
                          checked-icon="check"
                          color="green"
                          unchecked-icon="clear"
                        />
                    </div>

                  </q-card-section>

                  <!-- Dialog Add or Update Team : Buttons Add or Update By Case updateIcon Linked Watch -->
                  <q-card-actions align="right" class="bg-white text-teal">
                    <q-btn flat :label="updateIcon?'Update':'Add'" v-if="listenUpdateValue"  @click="()=>{updateIcon?updateTeam():createTeam()}" />
                    <q-btn flat label="Cancel" v-close-popup />
                  </q-card-actions>
                </q-card>
              </q-dialog>
              </div>

              <!-- Button Remove Team-->
            <q-btn class="q-ml-lg q-mr-xl" @click="removeTeam" color="red" :disable="selected.length===0" label="Remove Team" />
            <!-- Input Search Team-->
            <q-input borderless dense debounce="300" v-model="filter" placeholder="Search">
              <template v-slot:append>
                <q-icon name="search" />
              </template>
            </q-input>
          </template>
      </q-table>
    </div>
  </template>
  
  <script>
  // Import 
  import { ref,watch,onUpdated, onBeforeMount} from 'vue'
  import {useQuasar,QSpinnerPuff} from 'quasar'
  import { useStrorage } from "src/stores/storage";
  import { api } from "src/boot/axios";
  // State Initial for get Data from the server
  const Storage = useStrorage();
  const team=ref([])
  const users=ref([])
  const teamMembres=ref([])
  const stringOptions=ref([])
  // Columns Table
  const columns = [
    {name: 'idTeam',required: true,label: 'Id',field: 'idTeam',align: 'left',format: val => `${val}`,sortable: true},
    { name: 'name', align: 'center', label: 'Name', field: 'name', sortable: true },
    { name: 'teamLeader', label: 'TeamLeader', field: 'teamLeader', sortable: true },
    { name: 'membres', align: 'center', label: 'Membres', field: 'membres', sortable: true },
    { name: 'active', label: 'Active', field: 'active' },
    { name: 'update', align: 'center', label: 'Update', field: 'update', sortable: true },
  ]
  // Function getUsers for get Data Users from the server {load in State users && Pinia Storage users }
  const getUsers=async()=>{
    await api.get("v1/users").then((response)=>{
        Storage.users=response.data.data;
        users.value=Storage.users
    }).catch((error)=>{
        console.log(error)
    })
  }
  // Function getTeam for get Data Teams from the server {load in State team && Pinia Storage team }
  const getTeam=async()=>{
    await api.get('v1/team').then((response)=>{
        Storage.team=response.data.data
        team.value=Storage.team;
    }).catch((error)=>{
        console.log(error)
    })
  }
  // Function getTeamMembres for get Data TeamMembres from the server {load in State teamMembres && Pinia Storage teamMembres }
  const getTeamMembres=async()=>{
    await api.get("v1/get-users-not-in-team-membres").then((response)=>{
      Storage.teamMembres=response.data[0]
      teamMembres.value=Storage.teamMembres
      stringOptions.value=Storage.teamMembres
    }).catch((error)=>{
        console.log(error)
    })
  }


  export default {
    setup () {
      // Hook Quasar
      const $quasar = useQuasar()
      // Function Show Notify : Quasar Generate
      const showNotify=(type,message,textColor,position)=>{
        $quasar.notify({
          position:position,
          type: type,
          message:message,
          progress: true,
          textColor: textColor,
          actions: [{ icon: 'close', color: textColor }],
          timeout: 1500
        })
      }
      // Function Show Spinner : Quasar Generate
      const teamLoadingSpinnerShow=()=>{
        $quasar.loading.show({
          spinner: QSpinnerPuff,
          spinnerColor: 'blue',
          spinnerSize: 150,
          backgroundColor: 'white',
        })
      }
      //Function Hide Spinner : Quasar Generate
      const teamLoadingSpinnerHide=()=>{
        $quasar.loading.hide()
      }
      // State for data coming from Components
        const selected=ref([]),filter=ref(''),dialog= ref(false),dialogUpdate= ref(false),
        updateIcon=ref(false),selectTeamLeader=ref(''),
        selectMembres=ref(null),teamToggleActive=ref(true),nameTeam=ref(''),idTeam=ref(null),
        listenUpdateValue=ref(false),
        pagination=ref({
        page: 1,
        rowsPerPage: 5,
        sortBy:'idTeam',
        descending: false
      }),loading=ref(false)
        // Function Before Mount Component , this Function Call Functions Specifiy for get data users and team and team membres from server
        onBeforeMount(async()=>{
          teamLoadingSpinnerShow()
          getUsers()
          getTeam()
          getTeamMembres().then(()=>{
            teamLoadingSpinnerHide()
          })
        })
        // Function when Update State Specifiy for Components
        onUpdated(async()=>{
          getTeamMembres()
        })
        //Function Watch : This Function Watch and Listen The change State dialog(for add) and dialogUpdate (for update) for Dialog In order to determine whether Dialog Update or Add
        watch(dialog,(newdialog,prevdialog)=>{
          if(!newdialog){
            dialogUpdate.value=false
          }
        })

        watch(dialogUpdate,(newdialogUpdate,prevdialogUpdate)=>{
          if(newdialogUpdate){
            dialog.value=true
            updateIcon.value=true
          }else{
            updateIcon.value=false
          }
        })
        //Function Watch : This Function Watch and Listen The change State filter for get and query Data exact a server According to content state filter 
        watch(filter,async (newsearch,prevsearch)=>{
          if(newsearch!=''){
            loading.value=true
            await api.post('v1/team-query-filter?search='+newsearch).then((response)=>{
              team.value=response.data.data
              console.log(response.data)
            }).catch((error)=>{
                console.log(error)
            }).finally(()=>{
              loading.value=false
            })
          }else{
            team.value=Storage.team
          }
        })
      return {
        dialog,
        dialogUpdate,
        updateIcon,
        selectTeamLeader,
        selectMembres,
        filter,
        selected,
        columns,
        team,
        users,
        teamMembres,
        teamToggleActive,
        nameTeam,
        idTeam,
        listenUpdateValue,
        pagination,
        loading,
        // Function queryTeamSorting for Sorting Data Team According to Query With server
        async queryTeamSorting(e){
          pagination.value=e
          let sortBy=''
          if(e.sortBy==null || e.sortBy=='idTeam'){
              sortBy='id'
          }else{
            sortBy=e.sortBy
          }
          let stateDescending=e.descending?'-'+sortBy:sortBy
          loading.value=true
          await api.post('v1/team-query-sort?sort='+stateDescending).then((response)=>{
              Storage.team=response.data.data
              team.value=Storage.team;
          }).catch((error)=>{
              console.log(error)
          }).finally(()=>{
            loading.value=false
          })
        },
        // Function afterCreateTeam for empty the State Important after Create Team In order to prepare a Dialog Add
        afterCreateTeam(){
          listenUpdateValue.value=true
          idTeam.value=null
          nameTeam.value=''
          selectTeamLeader.value=''
          selectMembres.value=null
          teamMembres.value=Storage.teamMembres
          stringOptions.value=Storage.teamMembres
          teamToggleActive.value=true
        },
        // Function createTeam for create Team and send to server
        async createTeam(){
          let verficationName=false
          Storage.team.forEach((item)=>{
            if(item.idTeam!==idTeam.value){
              if(item.name==nameTeam.value){
                verficationName=true
              }
            }
          })
          if(verficationName){
            showNotify('warning','Team Name Duplicate','black','top')
          }
          if(nameTeam.value==''|| selectTeamLeader.value==[] || selectMembres.value.length==0){
            showNotify('warning','Warning Required Fields','black','top')
          }else{
            teamLoadingSpinnerShow()
          await api.post('v1/team',{idTeamLeader:selectTeamLeader.value.id,
            name:nameTeam.value,teamLeader:selectTeamLeader.value.name,
            active:teamToggleActive.value,dataTeamMembres:selectMembres.value
          }).then((response)=>{
            team.value=response.data.data
            nameTeam.value=''
            selectTeamLeader.value=[]
            selectMembres.value=null
            dialog.value=false
          }).catch((error)=>{
            console.log(error)
          }).finally(()=>{
            teamLoadingSpinnerHide()
          })
          }
        },
        // Function afterupdateTeam for empty the State Important after Create Team In order to prepare a Dialog Update
        afterupdateTeam(id,name,membres,active,nameTeamLeader){
          listenUpdateValue.value=false
          idTeam.value=id
          nameTeam.value=name
          selectTeamLeader.value={id:id,name:nameTeamLeader}
          selectMembres.value=membres
          teamMembres.value=[...membres,...teamMembres.value]
          stringOptions.value=teamMembres.value
          teamToggleActive.value=active
        },
        // Function updateTeam for update Team and send to server
        async updateTeam(){
          let verficationName=false
          Storage.team.forEach((item)=>{
            if(item.idTeam!==idTeam.value){
              if(item.name==nameTeam.value){
                verficationName=true
              }
            }
          })
          if(verficationName){
            showNotify('warning','Team Name Duplicate','black','top')
          }else{
            if(nameTeam.value==''|| selectTeamLeader.value==[] || selectMembres.value.length==0){
              showNotify('warning','Warning Required Fields','black','top')
            }else{
              teamLoadingSpinnerShow()
              let dataTeamMembres=selectMembres.value.map((item)=>{
                return {idTeam:idTeam.value,idUser:item.id}
              })
              await api.put(`v1/team/${idTeam.value}`,{idTeamLeader:selectTeamLeader.value.id,
                name:nameTeam.value,teamLeader:selectTeamLeader.value.name,
                active:teamToggleActive.value,dataTeamMembres:[...dataTeamMembres]
              }).then((response)=>{
                team.value=response.data.data
                idTeam.value=null
                nameTeam.value=''
                selectTeamLeader.value=[]
                selectMembres.value=null
                dialog.value=false
              }).catch((error)=>{
                console.log(error)
              }).finally(()=>{
                teamLoadingSpinnerHide()
              })
            }
          }
        },
        // Function removeTeam for delete One Team or Many Team
          async removeTeam(){
          selected.value.forEach(async(item)=>{
            teamLoadingSpinnerShow()
            await api.delete(`v1/team/${item.idTeam}`).then((response)=>{
                team.value=response.data.data
              }).catch((error)=>{
                console.log(error)
              })
            if(selected.value[selected.value.length-1].idTeam==item.idTeam){
              teamLoadingSpinnerHide()
            }
          })
        },
        // Function ChangeTeamActiveStatus for Update Status Team and send to server
        async ChangeTeamActiveStatus(idTeam,Status){
            const StatusSend=Status?1:0
            teamLoadingSpinnerShow()
            await api.put(`v1/team-active/${idTeam}`,{active:StatusSend}).then((response)=>{
                team.value=response.data.data
            }).catch((error)=>{
               console.log(error)
            }).finally(()=>{
              teamLoadingSpinnerHide()
            })
        },
        // Function filterFn for Show Value selected in Select Team Membres
        filterFn (val, update) {
        update(() => {
          if (val === '') {
              teamMembres.value=stringOptions.value
          }
          else {
            const needle = val.toLowerCase()
              teamMembres.value = stringOptions.value.filter(
              v => v.toLowerCase().indexOf(needle) > -1
            )
          }
        })
      },
      // Function createValue for load The data Team Membres Selected form select Team Membres In State selectMembres
      createValue (val, done) {
        if (val.length > 0) {
          const modelValue =(selectMembres.value || []).slice()
            val
            .split(/[,;|]+/)
            .map(v => v.trim())
            .filter(v => v.length > 0)
            .forEach(v => {
              if (stringOptions.value.includes(v) === false) {
                stringOptions.value.push(v)
              }
              if (modelValue.includes(v) === false) {
                modelValue.push(v)
              }
            })

          done(null)
          selectMembres.value = modelValue
        }
      }
      }
    }
  }
  </script>

