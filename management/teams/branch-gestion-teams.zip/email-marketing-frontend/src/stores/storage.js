import { defineStore } from "pinia"

export const useStrorage = defineStore("storage", {
  state: () => ({
    admins:[],
    users:[],
    team:[],
    teamMembres:[],
    roles: [],
    permissions:[],
  }),

  getters: {
    //
  },
});
