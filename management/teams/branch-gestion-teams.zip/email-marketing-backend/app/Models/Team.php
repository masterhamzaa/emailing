<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Team extends Model
{
    use HasFactory;

    protected $table='team';
    protected $fillable=[
        'id',
        'idTeamLeader',
        'name',
        'teamLeader',
        'active'
    ];
    protected $primaryKey='id';

    public function team_membres(){
        return $this->hasMany(TeamMembres::class);
    }
}
