<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\LoginRequest;
use App\Http\Resources\UserResource;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{

    public function __construct()
    {
        $this->middleware('throttle:3,1')->only('login');
    }

    public function login(LoginRequest $request)
    {
        $request->authenticate();

        // $remember = $request->boolean('remember');

        // $request->user()->createToken('api-token', $remember ? ['remember'] : []);
        $request->user()->createToken('api-token');

        return UserResource::make(auth()->user())
            ->additional([
                'message' => 'Logged in successful.'
            ]);

        // return response()->json(
        //     [
        //         'message' => 'Logged in successful.',
        //         'data' => [
        //             'user' => auth()->user(), //new SellerResource($profile)
        //         ]
        //     ]
        // );
    }

    public function logout(Request $request)
    {

        Auth::guard('web')->logout();

        $request->user()->tokens()->delete();


        return response()->json(
            [
                'message' => 'Logged out'
            ]
        );
    }

    public function user()
    {
        return UserResource::make(auth()->user());
    }
}
