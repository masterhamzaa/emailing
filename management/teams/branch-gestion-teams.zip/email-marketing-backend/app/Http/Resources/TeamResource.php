<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\DB;

class TeamResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'idTeam'=>$this->id,
            'idTeamLeader'=>$this->idTeamLeader,
            'name'=>$this->name,
            'teamLeader'=>$this->teamLeader,
            'active'=>$this->active,
            'membres'=>DB::table('team_membres')
                       ->join('users','users.id','=','team_membres.idUser')
                       ->where('team_membres.idTeam','=',$this->id)
                       ->select('users.id','users.name')
                       ->get()
        ];
    }
}
