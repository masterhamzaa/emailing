<?php

use App\Http\Controllers\UserController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\TeamController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')
->get('/user', function (Request $request) {
    return $request->user();
});
Route::apiResource('users', UserController::class);
Route::middleware(['web', 'api'])->group(function () {

    Route::prefix('v1')->group(function () {
        Route::group(['prefix' => 'auth'], function () {
            Route::post('login', [AuthController::class, 'login']);


            // test de push
            Route::get('testmessage', function() {
                return response()->json([
                    'message' => "test from hamza",
                ]);
            });

            Route::post('logout', [AuthController::class, 'logout'])->middleware('auth:sanctum');
        });

        Route::middleware(['auth:sanctum'])->group(function () {
            Route::get('user', [AuthController::class, 'user']);
            Route::apiResource('users', UserController::class);
            /*-----------------------Route : Team&TeamMembres------------------------*/
            Route::apiResource('team',TeamController::class);
            Route::controller(TeamController::class)->group(function () {
                Route::get('get-users-not-in-team-membres','get_users_not_in_team_membres');
                Route::put('team-active/{team}','update_team_active');
                Route::post('team-query-filter','team_query_filter');
                Route::post('team-query-sort','team_query_sort');
            });
            /*-----------------------------------------------------------------------*/
        });

    });
});
