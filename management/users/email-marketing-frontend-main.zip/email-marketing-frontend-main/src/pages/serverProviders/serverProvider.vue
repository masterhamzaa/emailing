<template>
  <ResourceIndex :columns="columns"
                 :defaultItem="defaultItem"
                 resource="v1/server-providers">
    <template #update-form="{ item }">
      <q-form class="q-gutter-md">
        <q-input label="Name"
                 v-model="item.name"
                 autofocus
                 style="width: 300px" />

        <q-select v-model="item.status"
                  :options="statusOptions"
                  emit-value
                  label="Status"
                  style="width: 300px" />
      </q-form>
    </template>

    <template #create-form="{ item }">
      <q-form class="q-gutter-md">
        <q-input autofocus
                 label="Name"
                 v-model="item.name" />

        <q-select v-model="item.status"
                  :options="statusOptions"
                  emit-value
                  label="Status" />

      </q-form>
    </template>
  </ResourceIndex>
</template>

<script setup>
import ResourceIndex from '../Verticals/ResourceIndex.vue';

const columns = [
  {
    name: 'id',
    align: 'left',
    label: 'ID',
    field: 'id',
    sortable: true
  },
  {
    name: 'name',
    align: 'left',
    label: 'Name',
    field: 'name',
    sortable: true
  },
  {
    name: 'status',
    align: 'left',
    label: 'Status',
    field: 'status',
    sortable: true
  },

  {
    name: 'created_by',
    align: 'left',
    label: 'Created By',
    field: (row) => row.created_by?.email ?? 'N/A',
    sortable: true,
  },

  {
    name: 'created_at',
    align: 'left',
    label: 'Created At',
    field: 'created_at',
    sortable: true
  },

  {
    name: 'actions',
    align: 'left',
    label: 'Actions',
  }
];

const statusOptions = [
  {
    label: 'Active',
    value: 'active'
  },
  {
    label: 'Inactive',
    value: 'inactive'
  }
];

const defaultItem = {
  name: '',
  status: 'active'
};
</script>
