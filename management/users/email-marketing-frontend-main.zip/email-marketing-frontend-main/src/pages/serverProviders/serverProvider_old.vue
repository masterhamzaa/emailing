<!-- eslint-disable vue/valid-v-for -->
<!-- eslint-disable vue/require-v-for-key -->
<template >
  <div class="q-pa-md">

    <!-- ADD server provider -->

    <q-dialog v-model="addProvider">
      <q-card class="my-card">
        <q-card-section>
          <q-form class="q-gutter-md">
            <q-input autofocus label="Name" v-model="nameProvider" name="name" type="text" lazy-rules />
            <q-select name="status" v-model="status" :options="statusOptions" label="Status" lazy-rules style="width: 300px" />
            <q-input label="Created By" v-model="createdBy" type="email" name="created_by" lazy-rules 
              style="width: 300px" />
            <div class="q-pa-md">
              <div class="q-gutter-md row items-start">
                <!-- <q-select filled v-model="roleadd" :options="roles" name="role" label="Role"
                  style="width: 300px;margin-left: -2px;" /> -->
                <!--  <q-select filled v-model="permissionsadd" multiple :options="optionsPermissions" label="Permissions"
                  style="width: 250px" /> -->
              </div>
            </div>

          </q-form>
        </q-card-section>
        <q-separator />
        <q-card-actions align="right">
          <q-btn flat color="blue" round icon="add" @click="() => { addProviders(); addProvider = false }" />
          <q-btn v-close-popup flat color="primary" label="close" />
        </q-card-actions>
      </q-card>
    </q-dialog>

    
    <!-- EDIT Provider -->
    <q-dialog v-model="editProvider">
      <q-card class="my-card">
        <q-card-section>
          <q-form class="q-gutter-md">
            <!-- <q-input label="id" v-model="id" lazy-rules /> -->
            <q-input label="Name" type="text" v-model="nameProvider" name="name" autofocus lazy-rules style="width: 300px" />
            <q-select name="status" v-model="status" :options="statusOptions" label="Status" lazy-rules style="width: 300px" />
            <q-input label="Created BY" v-model="createdBy" type="text" name="created_by" lazy-rules required
              style="width: 300px" />

          </q-form>
        </q-card-section>
        <q-separator />
        <q-card-actions align="right">
          <q-btn flat color="green" round icon="edit" @click="() => { editProviders(); editProvider = false }" />
          <q-btn v-close-popup flat color="primary" label="close" />
        </q-card-actions>
      </q-card>
    </q-dialog>

    <!-- DISPLAY DATA -->

        <q-table
      flat bordered
      ref="tableRef"
      :rows="Providers"
      :columns="columns"
      row-key="id"
      :filter="filter"
      :loading="cantlook"
      selection="multiple"
      v-model:selected="selected"
      v-model:pagination="pagination"
      @request="onRequest"
    >
    
      <template v-slot:top>
        <q-btn color="primary" :disable="selected.length > 0" label="Add Provider" @click="addProvider = true" />
        <q-btn class="q-ml-sm" color="red" :disable="selected.length === 0" label="Remove Provider" @click="removeProvider" />
        <q-btn class="q-ml-sm" label="Edit Provider" color="blue" :disable="selected.length === 0 || selected.length > 1"
          @click="() => {
            nameProvider = selected[0].name
            status = selected[0].status
            createdBy=selected[0].created_by
            editProvider = true
          }" />

        <q-space />
        <q-input borderless dense debounce="300" color="primary" v-model="filter" placeholder="Search">
          <template v-slot:append>
            <q-icon name="search" />
          </template>
        </q-input>
      </template>
      <template v-slot:no-data="{ icon, message, filter }">
        <div class="full-width row flex-center text-accent q-gutter-sm">
          <q-icon size="2em" name="sentiment_dissatisfied" />
          <span>
            Well this is sad... {{ message }}
          </span>
          <q-icon size="2em" :name="filter ? 'filter_b_and_w' : icon" />
        </div>
      </template>
    </q-table>
    <div class="q-mt-md">
      <!-- Selected: {{ JSON.stringify(selected) }} -->
    </div>
  </div>
</template>

<script>
import { defineComponent, ref } from 'vue'
import { useStrorage } from "src/stores/storage";
import { api } from "src/boot/axios";
import { Notify } from 'quasar'

//import { Loading } from 'quasar';
const Storage = useStrorage();
const Providers = ref([])

const cantlook = ref(false)
const admin = ref(false)

const columns = [
  { name: 'id', align: 'left', label: 'ID', field: 'id', sortable: true },
  { name: 'Name', align: 'left', label: 'Name', field: 'name', sortable: true },
  { name: 'Status', align: 'left', label: 'Status', field: 'status',sortable: true },
  { name: 'Created By', align: 'left', label: 'Created By', field: 'created_by',sortable: true  },
  { name: 'Created At', align: 'left', label: 'Created At', field: 'created_at',sortable: true  },
];



const getdata = async () => {
  cantlook.value = true
  await api
    .get("v1/Providers")
    .then((response) => {
      Storage.Providers = response.data.data;
      Providers.value = Storage.Providers
      console.log(Providers.value)
    })
    .catch((error) => {
      console.log(error)
    });
  cantlook.value = false
}

export default defineComponent({
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Providers",
  beforeRouteEnter(to, from, next) {
    if (!Storage.authority) {
      next({ name: "dashboard" });
    }
    else next()
  },

  created() { getdata() },
  setup() {

    let valid = ref(false);
    const loading = ref(false), filter = ref(''), rowCount = ref(10), rows = ref([]), selected = ref([])
    // add Providers
    const idProviders = ref(null), nameProvider = ref(""), status = ref(""), createdBy = ref("")

      



    return {
      cantlook,
      admin,
      valid,
       Providers,
      //edit test
      editProvider: ref(false),
      //add user
      addProvider: ref(false), idProviders,  nameProvider, status, createdBy,     
      statusOptions: ['activated', 'inactivated'],



      //table
      columns, rows, loading, filter, rowCount, selected,
      // Operations Logic
      addProviders() {
        if (nameProvider.value !== "", status.value !== "" && createdBy.value !== "" ) {
          valid.value = true
        }
        if (valid.value) {
          try {
            api.post("v1/providersStore", {
              name: nameProvider.value,
              status: status.value,
              created_by: createdBy.value,
            }).then(res => console.log(res)).catch(e => console.log(e))
            getdata()
            this.nameProvider.value = ""; status.value = ""; createdBy.value = "";  selected.value = []
          } catch (err) {
            Notify.create({
              message: "Error : " + err,
              color: "red"
            })
          }
        } else Notify.create({
          message: "Check your fields again",
          color: "red"
        })

      },
      removeProvider() {
        selected.value.forEach(row => {
          const index = rows.value.indexOf(row);
          console.log(index)
          console.log(rows.value)
          if (index !== -1) {
            rows.value.splice(index, 1);
          }
          const deloperation = async () => {

            await api.delete("v1/providers/" + row.id, row).then(res => console.log(res.data)).catch(e => Notify.create({
              message: "Server Error : " + e,
              color: "red"
            }))
          }
          deloperation()
        });
        Notify.create({
          message: selected.value.length + " Provider deleted successfuly",
          color: "green"
        })
        selected.value = []
        getdata()

      },
      editProviders() {
        if (this.nameProvider.value !== "" && status.value !== "" && createdBy.value !== "") {
          valid.value = true
        }
        if (valid.value) {
          try {
            api.post("v1/providersUpdate/{id}", {
              idProviders: selected.value[0].id,
              name: nameProvider.value,
              status: status.value,
              created_by: createdBy.value,
            }).then(res => Notify.create({
              message: "Provider " + nameProvider.value + " edited successfuly",
              color: "green"
            })).catch(e => Notify.create({
              message: "Server Error : " + e,
              color: "red"
            }))
            getdata()
            nameProvider.value = ""; status.value = ""; createdBy.value = ""; selected.value = []

          } catch (e) {
            Notify.create({
              message: "Error : " + e,
              color: "red"
            })
          }
        } else Notify.create({
          message: "Check your fields again",
          color: "red"
        })
      }
     


    }
  }
})
</script>

