<template>
  <q-page class="q-pa-sm">
    <q-card class="no-shadow" bordered>
      <q-card-section class="row q-pa-lg">
        <span class="text-body1 text-grey-8 text-weight-bold">
          © 2020 Workflow, Inc. All rights reserved.
        </span>
        <q-space></q-space>
        <q-btn icon="fab fa-github" flat dense color="grey-8"></q-btn>
        <q-btn icon="fab fa-facebook" flat dense color="grey-8"></q-btn>
        <q-btn icon="fab fa-twitter" flat dense color="grey-8"></q-btn>
        <q-btn icon="fab fa-instagram" flat dense color="grey-8"></q-btn>
      </q-card-section>
    </q-card>


    <q-card class="q-mt-md row no-shadow" bordered>
      <q-card-section class="col-12 text-center q-pa-lg">

        <q-btn icon="fab fa-github" flat dense color="grey-8"></q-btn>
        <q-btn icon="fab fa-facebook" flat dense color="grey-8"></q-btn>
        <q-btn icon="fab fa-twitter" flat dense color="grey-8"></q-btn>
        <q-btn icon="fab fa-instagram" flat dense color="grey-8"></q-btn>
        <br/>

        <div class="text-body1 q-mt-sm text-grey-8 text-weight-bold">
          © 2020 Workflow, Inc. All rights reserved.
        </div>
      </q-card-section>
    </q-card>

    <q-card class="q-mt-md row no-shadow" bordered>
      <q-card-section class="col-12 row text-center q-pa-lg">
        <div class="col-12 q-col-gutter-x-lg">
          <a class="text-indigo-8 text-weight-bold" href="#" style="text-decoration: none">About Us</a>
          <a class="text-indigo-8 text-weight-bold" href="#" style="text-decoration: none">Blog</a>
          <a class="text-indigo-8 text-weight-bold" href="#" style="text-decoration: none">News</a>
          <a class="text-indigo-8 text-weight-bold" href="#" style="text-decoration: none">Jobs</a>
          <a class="text-indigo-8 text-weight-bold" href="#" style="text-decoration: none">Press</a>
        </div>
        <br/>
        <div class="text-body1 col-12 q-mt-sm text-grey-8 text-weight-bold">
          © 2020 Workflow, Inc. All rights reserved.
        </div>
        <br/>
        <div class="col-12">
          <q-btn icon="fab fa-github" flat dense color="grey-8"></q-btn>
          <q-btn icon="fab fa-facebook" flat dense color="grey-8"></q-btn>
          <q-btn icon="fab fa-twitter" flat dense color="grey-8"></q-btn>
          <q-btn icon="fab fa-instagram" flat dense color="grey-8"></q-btn>
        </div>
      </q-card-section>
    </q-card>
  </q-page>
</template>

<script>
export default {
  name: "Footer"
}
</script>

<style scoped>

</style>
