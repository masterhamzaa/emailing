<template>
  <q-layout>
    <q-page-container>
      <q-page class="flex bg-image flex-center">
        <q-card v-bind:style="$q.screen.lt.sm ? { 'width': '80%' } : { 'width': '30%' }">
          <q-card-section>
            <q-avatar size="103px" class="absolute-center shadow-10">
              <img src="profile.svg">
            </q-avatar>
          </q-card-section>
          <q-card-section>
            <div class="text-center q-pt-lg">
              <div class="col text-h6 ellipsis">
                Log in
              </div>
            </div>
          </q-card-section>
          <q-card-section>
            <q-form class="q-gutter-md">
              <q-input label="Email" v-model="email"  lazy-rules />

              <q-input label="Password" v-model="password" type="password" lazy-rules
                required />

              <div>
                <q-btn :loading="loading" @click="submit" color="black"> Submit </q-btn>
              </div>
            </q-form>
          </q-card-section>
        </q-card>
      </q-page>
    </q-page-container>
  </q-layout>
</template>

<script setup>
import { api } from "src/boot/axios";
import { ref } from "vue";
import { useRouter } from "vue-router";
import { useAuthStore } from "src/stores/auth-store";

const email = ref("");
const password = ref("");
const loading = ref(false);

const getCsrfCookie = async () => {
  return await api.get("/sanctum/csrf-cookie");
};

const router = useRouter();

const authStore = useAuthStore();

const redirectToHome = () => {
  router.push({ name: "dashboard" });
};

const submit = async () => {
  loading.value = true;
  try {
    await getCsrfCookie();

    const response = await api.post("/v1/auth/login", {
      email: email.value,
      password: password.value,
    });

    authStore.user = response.data.data;
    redirectToHome();
  } catch (error) {

    console.log(error);
  } finally {
    loading.value = false;
  }
};
</script>

<style>

.bg-image {
  background-image: linear-gradient(135deg, #7028e4 0%, #e5b2ca 100%);
}

</style>
