<!-- eslint-disable vue/valid-v-for -->
<!-- eslint-disable vue/require-v-for-key -->
<template >
  <div class="q-pa-md">
    <!-- ATTACH ROLE TO USERS -->
    <q-dialog v-model="addRole">
      <q-card class="my-card">
        <q-card-section>
          <q-form class="q-gutter-md">
            <div style="row-gap: 4px;" class="row q-pa-md">
              <div id="wind" v-for="user in selected" :key="user.id" class="q-pa-md">
                {{ user.email }}
              </div>
              <div class="q-gutter-md row items-center">
                <q-select filled v-model="roleadd" :options="roles" name="role" label="Role"
                  style="width: 300px;margin-left: -2px;" />
                <q-select filled v-model="permissionsadd" multiple :options="permissions" name="permission"
                  label="Permissions" use-chips style="width: 300px;margin-left: -2px;" />
              </div>
            </div>
          </q-form>
        </q-card-section>
        <q-separator />
        <q-card-actions align="right">
          <q-btn flat color="orange" round icon="security" @click="() => { addRolePermission(); addRole = false }" />
          <q-btn v-close-popup flat color="black" label="close" />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!-- ADD USER -->
    <q-dialog v-model="adduser">
      <q-card class="my-card">
        <q-card-section>
          <q-form class="q-gutter-md">
            <q-input autofocus label="Name" v-model="nameuser" name="name" type="text" lazy-rules style="width: 300px" />
            <q-input label="Email" v-model="email" type="email" name="email" lazy-rules style="width: 300px;" />
            <q-input label="Password" v-model="password" type="password" name="password" lazy-rules
              style="width: 300px" />
            <div class="q-pa-md">
              <div class="q-gutter-md row items-start">
                <!-- <q-select filled v-model="roleadd" :options="roles" name="role" label="Role"
                  style="width: 300px;margin-left: -2px;" /> -->
                <!--  <q-select filled v-model="permissionsadd" multiple :options="optionsPermissions" label="Permissions"
                  style="width: 250px" /> -->
              </div>
            </div>

          </q-form>
        </q-card-section>
        <q-separator />
        <q-card-actions align="right">
          <q-btn flat color="blue" round icon="add" @click="() => { addUser(); adduser = false }" />
          <q-btn v-close-popup flat color="primary" label="close" />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!-- EDIT USER -->
    <q-dialog v-model="edituser">
      <q-card class="my-card">
        <q-card-section>
          <q-form class="q-gutter-md">
            <q-input label="Name" type="text" v-model="nameuser" name="name" autofocus lazy-rules style="width: 300px" />
            <q-input label="Email" v-model="email" type="email" name="email" lazy-rules style="width: 300px" />
            <q-input label="Password" v-model="password" type="password" name="password" lazy-rules
              requiredstyle="width: 300px" />
          </q-form>
        </q-card-section>
        <q-separator />
        <q-card-actions align="right">
          <q-btn flat color="green" round icon="edit" @click="() => { editUser(); edituser = false }" />
          <q-btn v-close-popup flat color="primary" label="close" />
        </q-card-actions>
      </q-card>
    </q-dialog>


    <!-- DISPLAY DATA -->
    <q-table
      flat bordered
      ref="tableRef"
      :rows="users"
      :columns="columns"
      row-key="id"
      :filter="filter"
      :loading="cantlook"
      selection="multiple"
      v-model:selected="selected"
      v-model:pagination="pagination"
      binary-state-sort
      @request="onRequest"
    >
      <template v-slot:top>
        <q-btn color="primary" :disable="selected.length > 0" label="Add User" @click="adduser = true" />
        <q-btn class="q-ml-sm" color="red" :disable="selected.length === 0" label="Remove user" @click="removeUser" />
        <q-btn class="q-ml-sm" label="Edit User" color="blue" :disable="selected.length === 0 || selected.length > 1"
          @click="() => {
            nameuser = selected[0].name
            email = selected[0].email
            edituser = true
          }" />

        <q-btn class="q-ml-sm" color="orange" :disable="selected.length === 0" label="role" @click="addRole = true" />
        <q-space />
        <q-input borderless dense debounce="300" color="primary" v-model="filter" placeholder="Search">
          <template v-slot:append>
            <q-icon name="search" />
          </template>
        </q-input>
      </template>
      <template v-slot:no-data="">
        <div class="full-width row flex-center text-blue-11 q-gutter-sm">
          <span>
            <q-spinner-grid color="blue" size="2em" />
            <q-tooltip :offset="[0, 8]">QSpinnerGrid</q-tooltip>
          </span>
        </div>
      </template>
    </q-table>
    <div class="q-mt-md">
      <!-- Selected: {{ JSON.stringify(selected) }} -->
    </div>
  </div>
</template>

<script>
import { defineComponent, ref} from 'vue'
import { useStrorage } from "src/stores/storage";
import { api } from "src/boot/axios";
import { Notify } from 'quasar'
const Storage = useStrorage();
const users = ref([])
const roles = ref([])
const permissions = ref([])
const cantlook = ref(false)


// server side pagination process
const tableRef = ref()
const pagination = ref({
  sortBy: 'desc',
  descending: false,
  page: 1,
  rowsPerPage: 5,
  rowsNumber: 10
})

//const from=ref(1) // offset
//const rowPerPage=ref(5)  //limit
const total=ref(10)
const filter = ref('')

/*__________________________________*/

const columns = [
  { name: 'id', align: 'left', label: 'id', field: 'id', sortable: true },
  { name: 'Name', align: 'left', label: 'Name', field: 'name', sortable: true },
  { name: 'Email', align: 'left', label: 'Email', field: 'email' },
]
const getroles = async () => {
  await api.get("v1/roles").then(res => {
    console.log(res.data)
    Storage.roles = res.data.roles;
    roles.value = Storage.roles;
  }).catch(e => console.log(e))
}
const getpermissions = async () => {
  await api.get("v1/permissions").then(res => {
    console.log(res.data)
    Storage.permissions = res.data.permissions;
    permissions.value = Storage.permissions;
  }).catch(e => console.log(e))
}

const notif = (msg, color) => {
  return Notify.create({
    message: msg,
    color: color
  })
}
// F I L T E R
const query = async (val)=>{
    await api.post("v1/grep-data",{req:val})
    .then(res=> {
      console.log(res.data.res)
      users.value=res.data.res
      if (users.value.length===0) {notif("No records match filter value",'red')}
    })
    .catch(e=>console.log(e))
}



export default defineComponent({
  // eslint-disable-next-line vue/multi-word-component-names
  name: "users",
  beforeRouteEnter(to, from, next) { if (!Storage.authority) { next({ name: "dashboard" }); } else next() },
  mounted() {tableRef.value.requestServerInteraction()},
  created() { getroles(); getpermissions(); },
  setup() {
    //loading
    const loading = ref(false),
    //rows => users.value
    //selected
    selected = ref([]),
    //filtrage
    filter = ref('')
    //user stuff
    const nameuser = ref(""), email = ref(""), password = ref(""),
    // roles
    roleadd = ref(""),
    // permissions
    permissionsadd = ref([])

    // server side operation
    const grepData = async (search,s,d)=> {
      cantlook.value=true
      if (search!=="") {query(search);return}
      if (search===""||!search) {
        await api.post("v1/slices",{
        debut: (pagination.value.page - 1) * pagination.value.rowsPerPage,
        counter:pagination.value.rowsPerPage,
      }).then( res=>{
        Storage.users=res.data.res
        users.value=res.data.res
        console.log(s,d)
        if (s) {
        const val = s === 'Name'
          ? (d
              ? (a, b) => (a.name > b.name ? -1 : a.name < b.name ? 1 : 0)
              : (a, b) => (a.name > b.name ? 1 : a.name < b.name ? -1 : 0)
            )
          : (d
              ? (a, b) => (parseFloat(b[ s ]) - parseFloat(a[ s ]))
              : (a, b) => (parseFloat(a[ s ]) - parseFloat(b[ s ]))
            )
        users.value.sort(val)
      }
        total.value=res.data.total
      }).catch(e=>notif("SERVER Error : "+e,'red'))
      }
      cantlook.value=false
    }
    function onRequest(props) {
      const fil = props.filter
      filter.value=fil
      if (fil!=="") {
        grepData(filter.value,"","")
        return
      }
      if (fil=="") {

        const { page, rowsPerPage,sortBy, descending } = props.pagination
        pagination.value.rowsNumber = total.value
        pagination.value.sortBy = sortBy
        pagination.value.descending = descending
        console.log(pagination.value.rowsNumber)
        //F R O M
        //const startRow = (page - 1) * rowsPerPage
        pagination.value.page = page
        //L I M I T
        pagination.value.rowsPerPage =  rowsPerPage === 0 ? pagination.value.rowsNumber : rowsPerPage
        grepData("",sortBy, descending)
      }
    }

    return {
      //user credentiels
      nameuser, email, password,
      //notification
      notif,
      //loading
      cantlook,
      //table
      columns, loading, filter, selected,
      //modal
      adduser: ref(false), edituser: ref(false),
      //add role && permissions
      addRole: ref(false), roleadd, permissionsadd,
      //data
      users, roles, permissions,

      //server operation
      total,
      tableRef,
      pagination,
      onRequest,

      // Operations process
      addUser() {
        if (nameuser.value !== "", email.value !== "" && password.value !== "") {
          try {
            api.post("v1/users/", {
              name: nameuser.value,
              email: email.value,
              password: password.value,
            }).then(res => { console.log(res); notif("created!", "green")}).catch(err => { console.log(err); notif("Error : " + err, 'red') })
            grepData("","Name",false)

            nameuser.value = ""; email.value = ""; password.value = ""; selected.value = []
          } catch (err) { notif("Err " + err, 'red') }
        } else notif("Check your fields again", 'red')
      },
      removeUser() {
        selected.value.forEach(row => {
          const deloperation = async () => {
            await api.delete("v1/users/" + row.id, row).then(res => console.log(res)).catch(e => notif("Server Error : " + e, "red"))
          }
          deloperation()

          notif("Deleted!", "green")
          grepData("","Name",false)

        });
        selected.value = []
       // grepData("","Name",false)
      },
      editUser() {
        if (nameuser.value !== "" && email.value !== "" && password.value !== "") {
          try {
            api.post("v1/admin/edit-user", {
              id: selected.value[0].id,
              name: nameuser.value,
              email: email.value,
              password: password.value,
            }).then(res => notif("Edited!", "green")).catch(e => notif("Server Error : " + e, "red")); grepData("")
            nameuser.value = ""; email.value = ""; password.value = ""; selected.value = []
          } catch (e) { notif("Error : " + e, "red") }
        } else notif("Check your fields again", 'red')
      },
      addRolePermission() {
        cantlook.value = true
        if (roleadd.value === "") notif("role option is empty!", "red")
        if (roleadd.value !== "") {
          try {

            selected.value.forEach(user => {
              api.post("v1/admin/attach-role-permissions/" + user.id, {
                role: roleadd.value,
                permissions: permissions.value
              }).then(res => { console.log(res); notif("Attached!", "green"); selected.value = [] }).catch(err => notif("Error!" + err, "red"))
            });
          } catch (error) { notif("Api Error!", "red") }
        }
        cantlook.value = false
      }
    }
  }
})
</script>
<style scoped>
  #wind {
    background-color: blueviolet;
    color: white;
    margin-right: 17px;
    border-radius: 150px;
    margin-left: -16px;
    padding: 5px 25px 5px 25px;
  }
</style>

