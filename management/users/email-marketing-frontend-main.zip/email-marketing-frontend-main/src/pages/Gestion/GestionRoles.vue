<template>
  <div>
    roles
  </div>
</template>
<script>
import { defineComponent, ref } from 'vue'
import { api } from "src/boot/axios";
import { useStrorage } from 'src/stores/storage';

const admin = ref(false)

export default defineComponent({
  beforeRouteEnter(to, from, next) {
    if (!useStrorage().authority) {
      next({ name: "dashboard" });
    }
    else next()
  },

  setup() {

    return {
      admin,
    }
  }

})
</script >
<style lang="eng">

</style>

