<template>
  <q-dialog v-model="visibleMutation"
            persistent>
    <q-card>
      <q-card-section class="row items-center">
        <q-avatar icon="delete"
                  color="primary"
                  text-color="white" />

        <span class="q-ml-sm">
          Are you sure you want to delete the selected items?
        </span>
      </q-card-section>

      <q-card-actions align="right">
        <q-btn flat
               label="Cancel"
               color="primary"
               :disable="deleting"
               v-close-popup />

        <q-btn flat
               label="Delete"
               color="primary"
               :loading="deleting"
               @click="handleDelete" />
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script setup>
import { computed } from 'vue';

const emit = defineEmits([
  'update:visible',
  'delete'
]);

const props = defineProps({
  visible: Boolean,

  deleting: Boolean,
});

const visibleMutation = computed({
  get: () => props.visible,
  set: (value) => emit('update:visible', value),
});

const handleDelete = () => emit('delete');
</script>
