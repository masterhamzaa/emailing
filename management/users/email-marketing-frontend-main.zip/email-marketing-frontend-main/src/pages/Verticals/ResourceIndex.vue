<template >
  <div class="q-pa-md">

    <!-- ADD Vertical Modal -->
    <q-dialog v-model="showCreateModal">
      <q-card>
        <q-card-section>
          <slot name="create-form"
                :item="currentItem"></slot>
        </q-card-section>
        <q-separator />
        <q-card-actions align="right">
          <q-btn color="primary"
                 label="Save"
                 @click="handleCreate" />

          <q-btn v-close-popup
                 flat
                 color="primary"
                 label="Close" />

        </q-card-actions>
      </q-card>
    </q-dialog>

    <!-- EDIT Vertical Modal -->
    <q-dialog v-model="showEditModal">
      <q-card>
        <q-card-section>
          <slot name="update-form"
                :item="currentItem"></slot>
        </q-card-section>
        <q-separator />
        <q-card-actions align="right">
          <q-btn color="primary"
                 label="Save Changes"
                 @click="handleUpdate" />

          <q-btn v-close-popup
                 flat
                 color="primary"
                 label="close" />
        </q-card-actions>
      </q-card>
    </q-dialog>

    <!-- Delete Multiple Verticals Modal Confirmation -->
    <ConfirmDeleteMultipleDialog v-model:visible="confirmDelete"
                                 :deleting="deleting"
                                 @delete="handleDelete" />


    <!-- Delete Single Vertical Modal Confirmation -->
    <ConfirmDeleteSingleDialog v-model:visible="confirmSingleDelete"
                               :name="itemToDelete?.name"
                               :deleting="deleting"
                               @delete="handleSingleDelete" />

    <!-- DISPLAY DATA -->
    <q-table flat
             bordered
             ref="tableRef"
             :rows="rows"
             :columns="columns"
             :row-key="rowKey"
             :filter="filter"
             :loading="loading"
             selection="multiple"
             v-model:selected="selected"
             v-model:pagination="pagination"
             @request="fetch">

      <template v-slot:top>
        <q-btn v-if="creatable"
               color="primary"
               icon="add"
               @click="handleCreateRequest" />

        <q-btn v-if="deletable"
               class="q-ml-sm"
               color="red"
               v-show="selected.length > 0"
               icon="delete"
               outline
               @click="handleDeleteConfirmation" />

        <q-space />

        <q-input borderless
                 dense
                 debounce="300"
                 color="primary"
                 v-model="filter"
                 placeholder="Search">
          <template v-slot:append>
            <q-icon name="search" />
          </template>
        </q-input>
      </template>
      <template v-slot:no-data="{ icon, message, filter }">
        <div class="full-width row flex-center text-accent q-gutter-sm">
          <q-icon size="2em"
                  name="sentiment_dissatisfied" />
          <span>
            Well this is sad... {{ message }}
          </span>
          <q-icon size="2em"
                  :name="filter ? 'filter_b_and_w' : icon" />
        </div>
      </template>

      <template #body-cell-actions="props">
        <q-td :props="props">
          <q-btn v-if="editable"
                 flat
                 dense
                 size="sm"
                 color="primary"
                 icon="edit"
                 @click="handleEditRequest(props.row)" />

          <q-btn v-if="deletable"
                 flat
                 dense
                 size="sm"
                 color="red"
                 icon="delete"
                 @click="handleSingleDeleteConfirmation(props.row)" />
        </q-td>
      </template>
    </q-table>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { useCrud } from '../../composables/network/useCrud.js';
import ConfirmDeleteSingleDialog from './ConfirmDeleteSingleDialog.vue';
import ConfirmDeleteMultipleDialog from './ConfirmDeleteMultipleDialog.vue';

const props = defineProps({
  columns: {
    type: Array,
    required: true
  },

  resource: {
    type: String,
    required: true
  },

  creatable: {
    type: Boolean,
    default: true
  },

  deletable: {
    type: Boolean,
    default: true
  },

  editable: {
    type: Boolean,
    default: true
  },

  defaultItem: {
    type: Object,
    default: () => ({})
  },

  rowKey: {
    type: String,
    default: 'id'
  }
});

const {
  loading,
  filter,
  pagination,
  rows,
  selected,
  deleting,
  create,
  remove,
  update,
  removeMany,
  fetch
} = useCrud(props.resource, {
  pagination: {
    page: 1,
    rowsPerPage: 5,
    sortBy: 'id',
    descending: false,
    rowsNumber: 0
  },
});

const currentItem = ref(props.defaultItem || {});

//edit test
const showEditModal = ref(false);

//add user
const showCreateModal = ref(false);

const confirmDelete = ref(false);

const itemToDelete = ref(null);

const confirmSingleDelete = ref(false);

const refresh = () => {
  fetch({
    pagination: pagination.value,
    filter: filter.value,
  });
}

onMounted(() => {
  refresh();
});

const handleCreate = () => {
  create(currentItem.value).then(() => {
    showCreateModal.value = false;

    currentItem.value = {};

    refresh();
  });
}

const handleUpdate = () => {
  update(currentItem.value.id, currentItem.value)
    .then(() => {
      showEditModal.value = false;

      currentItem.value = {};

      refresh();
    });
}

const handleDeleteConfirmation = () => {
  confirmDelete.value = true;
}

const handleSingleDeleteConfirmation = (row) => {
  itemToDelete.value = row;
  confirmSingleDelete.value = true;
}

const handleDelete = () => {
  removeMany().then(() => {
    confirmDelete.value = false;

    refresh();
  });
}

const handleSingleDelete = () => {
  remove(itemToDelete.value.id)
    .then(() => {
      confirmSingleDelete.value = false;

      itemToDelete.value = null;

      refresh();
    });
}

const handleEditRequest = (row) => {
  currentItem.value = {
    id: row.id,
    name: row.name,
    status: row.status,
  };

  showEditModal.value = true;
};

const handleCreateRequest = () => {
  currentItem.value = props.defaultItem || {};

  showCreateModal.value = true;
}
</script>
