<template>
  <q-layout view="lHh Lpr lFf">
    <q-header elevated>
      <q-toolbar>
        <q-btn flat
               dense
               round
               icon="menu"
               aria-label="Menu"
               @click="toggleLeftDrawer" />

        <q-toolbar-title> {{ user.name }} </q-toolbar-title>

        <div>

          <q-btn @click="logout"
                 :loading="loading"
                 icon="logout"
                 label="Logout" />


        </div>
      </q-toolbar>
    </q-header>

    <q-drawer v-model="leftDrawerOpen"
              show-if-above
              bordered
              class="bg-primary text-white">
      <q-list>
        <q-item to="/admin"
                active-class="q-item-no-link-highlighting">
          <q-item-section avatar>
            <q-icon name="dashboard" />
          </q-item-section>
          <q-item-section>
            <q-item-label>Dashboard</q-item-label>
          </q-item-section>
        </q-item>
        <q-item  to="/admin/users"
                active-class="q-item-no-link-highlighting">
          <q-item-section avatar>
            <q-icon name="person" />
          </q-item-section>
          <q-item-section>
            <q-item-label>Gestion Users</q-item-label>
          </q-item-section>
        </q-item>

        <q-item to="/admin/permissions"
                active-class="q-item-no-link-highlighting">
          <q-item-section avatar>
            <q-icon name="security" />
          </q-item-section>
          <q-item-section>
            <q-item-label>Permissions</q-item-label>
          </q-item-section>
        </q-item>

        <q-item to="/admin/roles"
                active-class="q-item-no-link-highlighting">
          <q-item-section avatar>
            <q-icon name="security" />
          </q-item-section>
          <q-item-section>
            <q-item-label>Roles</q-item-label>
          </q-item-section>
        </q-item>
        <q-item to="/admin/verticals"
                active-class="q-item-no-link-highlighting">
          <q-item-section avatar>
            <q-icon name="security" />
          </q-item-section>
          <q-item-section>
            <q-item-label>Verticals</q-item-label>
          </q-item-section>
        </q-item>

        <q-expansion-item icon="cloud"
                          label="Server Management">
          <q-expansion-item icon="map"
                            label="Server Providers">

            <q-list class="q-pl-lg">
              <q-item :to="{ name: 'server-providers' }"
                      active-class="q-item-no-link-highlighting">
                <q-item-section avatar>
                  <q-icon name="map" />
                </q-item-section>
                <q-item-section>
                  <q-item-label>Server Providers List</q-item-label>
                </q-item-section>
              </q-item>
            </q-list>
          </q-expansion-item>

          <!-- MTA -->
          <q-expansion-item icon="map"
                            label="MTA SERVERS">

            <q-list class="q-pl-lg">
              <q-item to="/admin/mtaServer"
                      active-class="q-item-no-link-highlighting">
                <q-item-section avatar>
                  <q-icon />
                </q-item-section>
                <q-item-section>
                  <q-item-label>MTA SERVERS List</q-item-label>
                </q-item-section>
              </q-item>
            </q-list>
          </q-expansion-item>

        </q-expansion-item>
        <q-item-label header> App Features </q-item-label>

        <EssentialLink v-for="link in featuresLink"
                       :key="link.title"
                       v-bind="link" />

      </q-list>

    </q-drawer>

    <q-page-container>
      <router-view />
    </q-page-container>
  </q-layout>
</template>

<script>
import { api } from "src/boot/axios";
import { useRouter } from "vue-router";
import { defineComponent, ref } from "vue";
import EssentialLink from "components/EssentialLink.vue";
import { useAuthStore } from "src/stores/auth-store";
import { useStrorage } from "src/stores/storage";

const flinks = [
  {
    title: "Servers",
    caption: "quasar.dev",
    icon: "server",
    link: "https://localhost/admin/servers",
  },
];

const authStore = useAuthStore();
const admin = ref(false)

export default defineComponent({
  name: "MainLayout",
  beforeRouteEnter(to, from, next) {
    api
      .get("v1/user")
      .then((response) => {
        authStore.user = response.data.data;
        api.get('v1/check/authority/' + authStore.user.id).then(
          response => { if (response.data.admin == true) { useStrorage().authority = true; admin.value = true } else { useStrorage().authority = false; admin.value = false } }
        )
        next();
      })
      .catch((error) => {
        if (error.response.status === 401) {
          next({ name: "login" });
        }
      });
  },
  setup() {
    const leftDrawerOpen = ref(false);
    const user = authStore.user;
    const loading = ref(false);
    const router = useRouter();
    const logout = async () => {
      loading.value = true;
      try {
        await api.post("/v1/logout");
        router.push({ name: "login" });
      } catch (error) {
        console.log(error);
      } finally {
        loading.value = false;
      }
    };
    return {
      admin, user, loading, featuresLink: flinks, leftDrawerOpen, logout,
      toggleLeftDrawer() {
        leftDrawerOpen.value = !leftDrawerOpen.value;
      },
    };
  },
});
</script>
