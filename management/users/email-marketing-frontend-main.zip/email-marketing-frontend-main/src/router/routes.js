const routes = [
  {
    path: "/admin",
    component: () => import("layouts/MainLayout.vue"),
    children: [
      {
        path: "",
        name: "dashboard",
        component: () => import("pages/IndexPage.vue"),
        props: true,
      },
      {
        path: "/admin/users",
        name: "users",
        component: () => import("pages/Gestion/GestionUsers.vue"),
        props: true,
      },
      {
        path: "/admin/permissions",
        name: "permissions",
        component: () => import("pages/Gestion/GestionPermissions.vue"),
        props: true,
      },
      {
        path: "/admin/roles",
        name: "roles",
        component: () => import("pages/Gestion/GestionRoles.vue"),
        props: true,
      },
      {
        path: "/admin/verticals",
        name: "verticals",
        component: () => import("pages/Verticals/VerticalsResourceIndex.vue"),
        props: true,
      },
      {
        path: "/admin/server-providers",
        name: "server-providers",
        component: () => import("pages/serverProviders/serverProvider.vue"),
        props: true,
      },
      {
        path: "/admin/mtaServer",
        name: "mtaServer",
        component: () => import("pages/MTA/mtaServer.vue"),
        props: true,
      },

      { path: "", component: () => import("pages/Dashboard.vue") },
      { path: "/Dashboard2", component: () => import("pages/Dashboard2.vue") },
      { path: "/Profile", component: () => import("pages/UserProfile.vue") },
      { path: "/Map", component: () => import("pages/Map.vue") },
      { path: "/MapMarker", component: () => import("pages/MapMarker.vue") },
      { path: "/TreeTable", component: () => import("pages/TreeTable.vue") },
      { path: "/StreetView", component: () => import("pages/StreetView.vue") },
      { path: "/Cards", component: () => import("pages/Cards.vue") },
      { path: "/Tables", component: () => import("pages/Tables.vue") },
      { path: "/Contact", component: () => import("pages/Contact.vue") },
      { path: "/Checkout", component: () => import("pages/Checkout.vue") },
      {
        path: "/Ecommerce",
        component: () => import("pages/ProductCatalogues.vue"),
      },
      { path: "/Pagination", component: () => import("pages/Pagination.vue") },
      { path: "/Charts", component: () => import("pages/Charts.vue") },
      { path: "/Calendar", component: () => import("pages/Calendar.vue") },
      { path: "/Directory", component: () => import("pages/Directory.vue") },
      { path: "/Footer", component: () => import("pages/Footer.vue") },
      { path: "/CardHeader", component: () => import("pages/CardHeader.vue") },
      //{path: "/admin/dashboard",name: "admindashboard",component: () => import("pages/dashboard.vue"),props: true,},
    ],
  },
  {
    path: "/login",
    name: "login",
    component: () => import("pages/LoginPage.vue"),
  },

  // Always leave this as last one,
  // but you can also remove it
  {
    path: "/:catchAll(.*)*",
    component: () => import("pages/ErrorNotFound.vue"),
  },
];

export default routes;
