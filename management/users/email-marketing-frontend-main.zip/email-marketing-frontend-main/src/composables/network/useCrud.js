import { Notify } from "quasar";
import { api } from "src/boot/axios";
import { ref } from "vue";

export function useCrud(resource, options = {}) {
  const pagination = ref(
    options.pagination ?? {
      sortBy: "id",
      descending: true,
      rowsNumber: 1000,
      page: 1,
      rowsPerPage: 10,
    }
  );

  const rows = ref([]);

  const loading = ref(false);

  const deleting = ref(false);

  const filter = ref(null);

  const selected = ref([]);

  const fetch = async (request) => {
    loading.value = true;

    api
      .get(resource, {
        params: {
          page: request.pagination.page,
          per_page: request.pagination.rowsPerPage,
          filter: request.filter,
          sort_by: request.pagination.sortBy,
          descending: request.pagination.descending,
        },
      })
      .then((response) => {
        rows.value = response.data.data;

        pagination.value.rowsPerPage = response.data.meta.per_page;
        pagination.value.rowsNumber = response.data.meta.total;
        pagination.value.page = response.data.meta.current_page;
        pagination.value.sortBy = response.data.meta.sort_by;
        pagination.value.descending = response.data.meta.descending;
      })
      .catch((error) => {
        console.log(error);
      })
      .finally(() => {
        loading.value = false;
      });
  };

  const create = async (data) => {
    return await api
      .post(resource, data)
      .then((res) => {
        selected.value = [];
      })
      .catch((e) => {
        // Handle Errors here.
      });
  };

  const update = async (id, data) => {
    return await api
      .put(`${resource}/${id}`, data)
      .then((res) => {
        selected.value = [];

        return res;
      })
      .catch((e) => {
        // Handle Errors here.
      });
  };

  const remove = async (id) => {
    deleting.value = true;

    return await api
      .delete(`${resource}/${id}`)
      .then((res) => {
        selected.value = [];
      })
      .catch((e) => {
        Notify.create({
          message: "Server Error : " + e,
          color: "red",
        });
      })
      .finally(() => {
        deleting.value = false;
      });
  };

  const removeMany = async () => {
    deleting.value = true;

    return await api
      .delete(resource, {
        data: {
          ids: selected.value.map((row) => row.id),
        },
      })
      .then((res) => {
        selected.value = [];
      })
      .catch((e) => {
        Notify.create({
          message: "Server Error : " + e,
          color: "red",
        });
      })
      .finally(() => {
        deleting.value = false;
      });
  };

  return {
    pagination,
    filter,
    loading,
    rows,
    selected,
    deleting,

    fetch,
    create,
    update,
    remove,
    removeMany,
  };
}
