import { defineStore } from "pinia"

export const useStrorage = defineStore("storage", {
  state: () => ({
    authority:null,
    admins:[],
    users:[],
    roles: [],
    permissions:[],
  }),

  getters: {
    //
  },
});
