<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;

use App\Models\Vertical;
use App\Models\Team;
use App\Models\TeamMembres;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            VerticalSeeder::class,
            ServerProviderSeeder::class,
        ]);

        // \App\Models\User::factory(10)->create();

        \App\Models\User::factory(30)->create();
        Team::factory(3)->create();
        $data = [
            ['idTeam' => 1,'idUser' => 1],
            ['idTeam' => 1,'idUser' => 2],
            ['idTeam' => 1,'idUser' => 3],
            ['idTeam' => 1,'idUser' => 4],
            ['idTeam' => 1,'idUser' => 5],
            ['idTeam' => 2,'idUser' => 6],
            ['idTeam' => 2,'idUser' => 7],
            ['idTeam' => 2,'idUser' => 8],
            ['idTeam' => 2,'idUser' => 9],
            ['idTeam' => 2,'idUser' => 10],
            ['idTeam' => 3,'idUser' => 11],
            ['idTeam' => 3,'idUser' => 12],
            ['idTeam' => 3,'idUser' => 13],
            ['idTeam' => 3,'idUser' => 14],
            ['idTeam' => 3,'idUser' => 15],
        ];

        DB::beginTransaction();

        try {
            foreach ($data as $item) {
                TeamMembres::create($item);
            }
            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
        }

        \App\Models\User::factory(10)->create([
            "id"=>config("app.admin_credentiels.id",1),
            "name"=>config("app.admin_credentiels.name","HAMZA"),
            "email"=>config("app.admin_credentiels.email","hamza777@gmail.com"),
            "password"=>bcrypt(config("app.admin_credentiels.password","openopen"))
        ]);

        // \App\Models\User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);
    }
}
