<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class ServerProviderSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        \App\Models\ServerProvider::factory()
            ->for(\App\Models\User::query()->inRandomOrder()->first(), 'createdBy')
            ->count(100)
            ->create();
    }
}