<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mta_servers', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('status');
            $table->string('server_provider');
            $table->date('expiration_date');
            $table->string('host_name');
            $table->string('main_ip');
            $table->integer('ssh_port');
            $table->string('login_type');
            //$table->foreign('provider_name')->references('name')->on('server_providers')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mta_servers');
    }
};
