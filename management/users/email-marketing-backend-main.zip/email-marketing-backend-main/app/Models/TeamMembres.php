<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TeamMembres extends Model
{
    use HasFactory;

    protected $table='team_membres';
    protected $primaryKey='idUser';
    public $incrementing = false;
    protected $fillable=[
        'idTeam',
        'idUser'
    ];

    public function user(){
        return $this->belongsTo(User::class);
    }

    public function team(){
        return $this->belongsTo(Team::class);
    }
}
