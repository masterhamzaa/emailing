<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use App\Http\Resources\UserResource;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use PhpParser\Node\Expr\Cast\String_;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\QueryBuilder\QueryBuilder as query;
class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     */

    public function checkAuthority(string $ref)
    {
        $users =  User::role('admin')->get('id')->toArray();
        $admin = false;
        foreach ($users as $user) {
            if ($ref == $user['id']) {
                $admin = true;
            }
        }
        return response()->json([
            "admin" => $admin
        ]);
    }

    /**
     * Edit user in database
     */

    public function editUser(Request $request)
    {
        $user = User::find($request->id);
        $user->update([
            "name" => $request->validate(['name' => 'required'])['name'],
            "email" => $request->validate(['email' => 'required|email:rfc'])['email'],
            "password" => bcrypt($request->validate(['password' => 'required|min:8'])['password'])
        ]);
        $user->save();
        return response()->json([
            "From server" => 'ressource updated... check your database',
        ]);
    }


    /**
     * Attach role to one user or many users
     */

    public function attachRole(Request $request, String $ref)
    {
        $user = User::find($ref);
        $user->assignRole($request->validate(["role" => "required"])['role']);
        foreach ($request->input('permissions') as $permission) {
            $user->givePermissionTo($permission);
        }
        return response()->json("Attached!");
    }

    /**
     * All Roles
     */
    public function roles()
    {
        return response()->json(["roles" => Role::all()->pluck('name')]);
    }

    /**
     * All Permissions
     */

    public function permissions()
    {
        return response()->json(["permissions" => Permission::all()->pluck('name')]);
    }


    /**
     * Filtrage
     */

    public function grepData(Request $params) {
        $return = query::for(User::class)
            ->where('name','like','%'.$params->req.'%')
            ->orWhere('email','like','%'.$params->req.'%')
            ->get();
        return response()->json([
            "res" => $return
        ]);
    }


    /**
     * Pagination
     */
    public function slices(Request $params) {
        $validated=$params->validate(["debut"=>"required","counter"=>"required",]);
        $return = DB::table('users')
            ->offset($validated["debut"])
            ->limit($validated["counter"])
            ->get();
        return response()->json(["res" => $return,"total"=>User::all()->count()]);
    }


}
