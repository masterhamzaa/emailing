<?php

namespace App\Http\Controllers;
use App\Models\MtaServer;

use Illuminate\Http\Request;

class MtaServerController extends Controller
{
        /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $query = MtaServer::query();

        // Search by different columns
        if ($request->has('search')) {
            $searchTerm = $request->input('search');
            $query->where('name', 'like', "%$searchTerm%")
                ->orWhere('status', 'like', "%$searchTerm%")
                ->orWhere('created_by', 'like', "%$searchTerm%");
        }

        // Filtering
        if ($request->has('filter')) {
            $filterTerm = $request->input('filter');
            $query->where('status', $filterTerm);
        }

        // Sorting
        if ($request->has('sort_by')) {
            $sortBy = $request->input('sort_by');
            $sortDirection = $request->input('sort_dir', 'asc');
            $query->orderBy($sortBy, $sortDirection);
        }

        // Pagination
        $perPage = $request->input('per_page', 5);
        $mtaServer = $query->paginate($perPage);

        return response()->json($mtaServer);
        // return view('verticals.index', compact('verticals'));

    }

  /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // return view('verticals.add');
    }
  
    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'status' => 'required',
            'server_provider'=>'required',
            'host_name'=>'required',
            'main_ip'=>'required',
            'expiration_date'=>'required',
            'ssh_port'=>'required',
            'login_type'=>'required'
        ]);
        
        MtaServer::create($request->all());
         
        return redirect()->route('mtaServers.index')
                        ->with('success','Product created successfully.');
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $mtaServer = MtaServer::findOrFail($id);

        return response()->json($mtaServer);
    }

     /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $mtaServers =MtaServer::find($id);
        // return view('verticals.edit',compact('verticals'));    
    }
    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request,$id)
    {        $mtaServer= MtaServer::find($id);

        $request->validate([
            'name' => 'required',
            'status' => 'required',
            'server_provider'=>'required',
            'host_name'=>'required',
            'main_ip'=>'required',
            'expiration_date'=>'required',
            'ssh_port'=>'required',
            'login_type'=>'required'
        ]);
        
        $mtaServer->update($request->all());
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $mtaServer = MtaServer::findOrFail($id);
        $mtaServer->delete();
        return response()->json(null, 204);
    }

}
