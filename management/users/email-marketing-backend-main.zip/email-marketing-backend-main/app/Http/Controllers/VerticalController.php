<?php

namespace App\Http\Controllers;

use App\Http\Resources\VerticalResource;
use App\Models\Vertical;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class VerticalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return AnonymousResourceCollection
     */
    public function index(Request $request): AnonymousResourceCollection
    {
        $query = Vertical::query()
            ->with('createdBy');

        // Search by different columns
        if ($request->has('filter')) {
            $searchTerm = $request->input('filter');
            $query->where('name', 'like', "%$searchTerm%")
                ->orWhere('status', 'like', "%$searchTerm%")
                ->orWhere('created_by', 'like', "%$searchTerm%");
        }

        // Sorting
        if ($request->has('sort_by')) {
            $sortBy = $request->input('sort_by');
            $sortDirection = $request->boolean('descending') ? 'desc' : 'asc';
            
            $query->orderBy($sortBy, $sortDirection);
        }

        // Pagination
        $verticals = $query->paginate($request->input('per_page'));

        return VerticalResource::collection($verticals)->additional([
            'meta' => [
                'sort_by' => $request->input('sort_by'),
                'descending' => $request->boolean('descending'),
            ]
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request): VerticalResource
    {
        $validated = $request->validate([
            'name' => 'required',
            'status' => 'required'
        ]);

        $vertical = new Vertical($validated);

        $vertical->createdBy()->associate(auth()->user());

        $vertical->save();

        return VerticalResource::make($vertical);
    }
    /**
     * Display the specified resource.
     *
     * @param  Vertical $vertical
     * @return VerticalResource
     */
    public function show(Vertical $vertical): VerticalResource
    {
        return VerticalResource::make($vertical);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Vertical $vertical): VerticalResource
    {
        $validated = $request->validate([
            'name' => 'required',
            'status' => 'required',
        ]);

        $vertical->update($validated);

        return VerticalResource::make($vertical);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  Vertical $vertical
     * @return JsonResponse
     */
    public function destroy(Vertical $vertical): JsonResponse
    {
        $vertical->delete();

        return response()->json([
            'message' => 'Vertical deleted successfully'
        ], 204);
    }

    /**
     * Remove the specified resources from storage.
     * 
     * @param Request $request
     * @return JsonResponse
     */
    public function destroyMany(Request $request): JsonResponse
    {
        $request->validate([
            'ids' => 'required|array'
        ]);

        $ids = $request->input('ids', []);

        Vertical::whereIn('id', $ids)->delete();

        return response()->json([
            'message' => 'Verticals deleted successfully'
        ], 204);
    }
}