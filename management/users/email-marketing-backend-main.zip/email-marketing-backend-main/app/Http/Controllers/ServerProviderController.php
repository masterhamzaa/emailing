<?php

namespace App\Http\Controllers;

use App\Http\Resources\ServerProviderResource;
use App\Models\ServerProvider;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class ServerProviderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return AnonymousResourceCollection
     */
    public function index(Request $request): AnonymousResourceCollection
    {
        $query = ServerProvider::query()
            ->with('createdBy');

        // Search by different columns
        if ($request->has('filter')) {
            $searchTerm = $request->input('filter');
            $query->where('name', 'like', "%$searchTerm%")
                ->orWhere('status', 'like', "%$searchTerm%")
                ->orWhere('created_by', 'like', "%$searchTerm%");
        }

        // Sorting
        if ($request->has('sort_by')) {
            $sortBy = $request->input('sort_by');
            $sortDirection = $request->boolean('descending') ? 'desc' : 'asc';
            
            $query->orderBy($sortBy, $sortDirection);
        }

        // Pagination
        $providers = $query->paginate($request->input('per_page'));

        return ServerProviderResource::collection($providers)->additional([
            'meta' => [
                'sort_by' => $request->input('sort_by'),
                'descending' => $request->boolean('descending'),
            ]
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request): ServerProviderResource
    {
        $validated = $request->validate([
            'name' => 'required',
            'status' => 'required'
        ]);

        $serverProvider = new ServerProvider($validated);

        $serverProvider->createdBy()->associate(auth()->user());

        $serverProvider->save();

        return ServerProviderResource::make($serverProvider);
    }
    /**
     * Display the specified resource.
     *
     * @param  ServerProvider $serverProvider
     * @return ServerProviderResource
     */
    public function show(ServerProvider $serverProvider): ServerProviderResource
    {
        return ServerProviderResource::make($serverProvider);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, ServerProvider $serverProvider): ServerProviderResource
    {
        $validated = $request->validate([
            'name' => 'required',
            'status' => 'required',
        ]);

        $serverProvider->update($validated);

        return ServerProviderResource::make($serverProvider);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  ServerProvider $serverProvider
     * @return JsonResponse
     */
    public function destroy(ServerProvider $serverProvider): JsonResponse
    {
        $serverProvider->delete();

        return response()->json([
            'message' => 'Server provider deleted successfully'
        ], 204);
    }

    /**
     * Remove the specified resources from storage.
     * 
     * @param Request $request
     * @return JsonResponse
     */
    public function destroyMany(Request $request): JsonResponse
    {
        $request->validate([
            'ids' => 'required|array'
        ]);

        $ids = $request->input('ids', []);

        ServerProvider::whereIn('id', $ids)->delete();

        return response()->json([
            'message' => 'Server providers deleted successfully'
        ], 204);
    }
}