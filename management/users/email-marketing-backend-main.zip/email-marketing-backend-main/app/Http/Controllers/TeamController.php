<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreTeamRequest;
use App\Http\Requests\UpdateTeamRequest;
use App\Http\Resources\TeamResource;
use App\Models\Team;
use App\Models\TeamMembres;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TeamController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return TeamResource::collection(Team::all());
    }

    /**
     * Display a listing of the resource.
     */
    public function getNotInTeamMembres()
    {
        $teamMembres = TeamMembres::pluck('idUser')->all();
        $users = User::whereNotIn('id', $teamMembres)->select('id','name')->get();
        return response()->json([
            $users
        ]);
    }

    /**
     * Store the form for creating a new resource.
     */
    public function store(StoreTeamRequest $request)
    {
        try {
            $team=Team::create($request->validated());
            foreach($request->dataTeamMembres as $item){
                TeamMembres::insert(['idTeam'=>$team->id,'idUser'=>$item['id']]);
            }
            return TeamResource::collection(Team::all());
        } catch(\Exception $e) {
            return response()->json([
                'message'=>$e
            ],400);
        }
    }

    /**
     * Update Team Status
     */
    public function updateTeamActive(Request $request,Team $team)
    {
        try {
            $team->update(['active'=>$request->active]);
            return TeamResource::collection(Team::all());
        } catch(\Exception $e) {
            return response()->json([
                'message'=>$e
            ],400);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateTeamRequest $request, Team $team)
    {
        try {
            $team->update($request->validated());
            DB::table('team_membres')->where('idTeam',$team->id)->delete();
            TeamMembres::insert($request->dataTeamMembres);
            return TeamResource::collection(Team::all());
        } catch(\Exception $e) {
            return response()->json([
                'message'=>$e
            ],400);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Team $team)
    {
        try {
            DB::table('team')->where('id',$team->id)->delete();
            return TeamResource::collection(Team::all());
        } catch(\Exception $e) {
            return response()->json([
                'message'=>$e
            ],400);
        }
    }
}
