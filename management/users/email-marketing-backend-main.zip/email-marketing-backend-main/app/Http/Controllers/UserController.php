<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreUserRequest;
use App\Http\Requests\UpdateUserRequest;
use App\Http\Resources\UserResource;
use Illuminate\Http\Request;
use App\Models\User;

use Spatie\QueryBuilder\AllowedFilter;
use Spatie\QueryBuilder\QueryBuilder;


class UserController extends Controller
{

    public function QBHAMZA(Request $req)
    {
        $users = QueryBuilder::for (User::class)
            ->where('name', 'like', '%' . $req->name . '%')
            ->orWhere('email', 'like', '%' . $req->name . '%')
            ->get();
        return response()->json([
            "users" => $users
        ]);
    }
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        // $users = User::role('admin')->get();
        $users = User::all();

        return UserResource::collection($users);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreUserRequest $request)
    {
        //validate before add
        $validated = $request->validate([
            'name' => 'required',
            'email' => 'required|email:rfc',
            'password' => 'required|min:8',
        ]);
        User::create([
            "name" => $validated['name'],
            "email" => $validated['email'],
            "password" => bcrypt($validated['password'])
        ]);
        return response()->json("Created!", 200);
    }

    /**
     * Display the specified resource.
     */
    public function show(User $user)
    {
        return UserResource::make($user);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateUserRequest $request, User $user)
    {
        $user->update($request->validated());

        return UserResource::make($user);
    }




    /**
     * Remove the specified resource from storage.
     */
    public function destroy(User $user)
    {
        $user->delete();
        //$user->forceDelete();  // this for personal data

        return response()->json([
            'success' => true,
            'message' => 'User Deleted Successfully.'
        ]);
    }
}