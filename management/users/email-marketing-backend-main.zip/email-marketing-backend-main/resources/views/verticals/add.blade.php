<!-- resources/views/verticals/create.blade.php -->

<h1>Create Vertical</h1>

<form action="{{ route('verticals.store') }}" method="POST">
    @csrf

    <label for="name">Name:</label>
    <input type="text" name="name" id="name" required>

    <label for="status">Status:</label>
    <input type="text" name="status" id="status" required>

    <label for="created_by">Created By:</label>
    <input type="text" name="created_by" id="created_by" required>

    <button type="submit">Create</button>
</form>
