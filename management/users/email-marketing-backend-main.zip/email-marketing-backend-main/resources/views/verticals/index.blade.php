<!-- resources/views/verticals/index.blade.php -->

<!-- Display search form -->
<form action="{{ route('verticals.index') }}" method="GET">
    <input type="text" name="search" placeholder="Search...">
    <button type="submit">Search</button>
</form>

<!-- Display filter form -->
<form action="{{ route('verticals.index') }}" method="GET">
    <select name="filter">
        <option value="active">Active</option>
        <option value="inactive">Inactive</option>
    </select>
    <button type="submit">Filter</button>
</form>

<!-- Display table with verticals -->
<table>
    <thead>
        <tr>
            <th><a href="{{ route('verticals.index', ['sort_by' => 'name', 'sort_dir' => 'asc']) }}">Name</a></th>
            <th><a href="{{ route('verticals.index', ['sort_by' => 'status', 'sort_dir' => 'asc']) }}">Status</a></th>
            <th><a href="{{ route('verticals.index', ['sort_by' => 'created_by', 'sort_dir' => 'asc']) }}">Created By</a></th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($verticals as $vertical)
        <tr>
            <td>{{ $vertical->name }}</td>
            <td>{{ $vertical->status }}</td>
            <td>{{ $vertical->created_by }}</td>

            <td>{{ $vertical->created_at->diffForHumans()  }}</td>
            <td>
                <!-- Add edit and delete buttons with appropriate routes -->
                <a href="{{ route('verticals.edit', $vertical->id) }}">Edit</a>
                <form action="{{ route('verticals.destroy', $vertical->id) }}" method="POST">
                    @csrf
                    @method('DELETE')
                    <button type="submit">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>

<!-- Display pagination links -->
{{ $verticals->links() }}
