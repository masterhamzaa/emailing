<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\MtaServerController;
use App\Http\Controllers\ServerProviderController;
use App\Http\Controllers\VerticalController;
use App\Http\Controllers\TeamController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware(['web', 'api'])->group(function () {
    Route::prefix('v1')->group(function () {
        Route::group(['prefix' => 'auth'], function () {
            Route::post('login', [AuthController::class, 'login']);
        });
        Route::middleware(['auth:sanctum'])->group(function () {
            Route::get('user', [AuthController::class, 'user']);

            Route::controller(AdminController::class)->group(function () {
                Route::apiResource('users', UserController::class);
                /*-----------------------Route : Team&TeamMembres------------------------*/
                Route::apiResource('team', TeamController::class);
                Route::get('teamMembres', [TeamController::class, 'getNotInTeamMembres']);
                Route::put('teamActive/{team}', [TeamController::class, 'updateTeamActive']);
                /*-----------------------------------------------------------------------*/
            });


            Route::apiResource('verticals', VerticalController::class);

            // Delete many
            Route::delete('verticals', [VerticalController::class, 'destroyMany']);

            Route::apiResource('server-providers', ServerProviderController::class);

            // Delete many
            Route::delete('server-providers', [ServerProviderController::class, 'destroyMany']);

            //Mta
            Route::get('mtaServer', [MtaServerController::class, 'index'])->name('mtaServer.index');
            Route::get('/mtaServerAdd', [MtaServerController::class, 'create'])->name('mtaServer.create');
            Route::post('mtaServerStore', [MtaServerController::class, 'store'])->name('mtaServer.store');
            Route::get('/mtaServerEdit/{id}', [MtaServerController::class, 'edit'])->name('mtaServer.edit');
            Route::put('mtaServerUpdate/{id}', [MtaServerController::class, 'update'])->name('mtaServer.update');
            Route::get('/mtaServer/{id}', [MtaServerController::class, 'show'])->name('mtaServer.show');
            Route::delete('mtaServer/{id}', [MtaServerController::class, 'destroy'])->name('mtaServer.destroy');

            Route::apiResource('users', UserController::class);


            Route::controller(AdminController::class)->group(function () {
                Route::get('check/authority/{ref}', 'checkAuthority');
                Route::get('roles', 'roles');
                Route::get('permissions', 'permissions');
                Route::post('admin/edit-user', 'editUser');
                Route::post('admin/attach-role-permissions/{ref}', 'attachRole');
                Route::post("grep-data","grepData");
                Route::post("slices","slices");
            });

            Route::post('logout', [AuthController::class, 'logout']);
        });
        //Route::apiResource('users', UserController::class);
        //Route::post('logout', [AuthController::class, 'logout']);
    });
});
