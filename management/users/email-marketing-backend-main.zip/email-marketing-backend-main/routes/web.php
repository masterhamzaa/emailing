<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\VerticalController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Route::get('/verticals', [VerticalController::class, 'index'])->name('verticals.index');
// Route::get('/verticalsAdd', [VerticalController::class, 'create'])->name('verticals.create');
// Route::post('/verticalsStore', [VerticalController::class, 'store'])->name('verticals.store');
// Route::get('/verticalsEdit/{id}', [VerticalController::class, 'edit'])->name('verticals.edit');
// Route::put('/verticalsUpdate/{id}', [VerticalController::class, 'update'])->name('verticals.update');

// Route::get('/verticals/{id}', [VerticalController::class, 'show'])->name('verticals.show');
// Route::delete('/verticals/{id}', [VerticalController::class, 'destroy'])->name('verticals.destroy');

//Route::resource('verticals', VerticalController::class);
